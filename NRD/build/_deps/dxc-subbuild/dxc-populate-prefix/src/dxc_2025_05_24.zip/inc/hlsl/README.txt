HLSL Standard Header Library
============================

The contents of this directory and subdirectories are the HLSL Standard Header
library. These headers are open source software. You may freely distribute all
or parts of these headers under the terms of the license agreement found in
LICENSE.txt.
